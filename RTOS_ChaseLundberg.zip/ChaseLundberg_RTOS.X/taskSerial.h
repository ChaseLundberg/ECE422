
#ifndef TASK_SERIAL_H
#define	TASK_SERIAL_H

#ifdef	__cplusplus
extern "C" {
#endif

    extern void taskSerial_init(void);


#ifdef	__cplusplus
}
#endif

#endif	/* TASK_BLINKY_H */

