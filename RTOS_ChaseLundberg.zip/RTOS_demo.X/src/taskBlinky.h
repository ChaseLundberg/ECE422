
#ifndef TASK_BLINKY_H
#define	TASK_BLINKY_H

#ifdef	__cplusplus
extern "C" {
#endif

    extern void taskBlinky_init(void);


#ifdef	__cplusplus
}
#endif

#endif	/* TASK_BLINKY_H */

